# Moonzer Student — iOS 1.1.0

Versi iOS dari aplikasi **Moonzer Student** untuk layanan siswa SMAN 2 Kota Tangerang Selatan.

> Proyek iOS harus dibuka dan di-build pada **macOS + Xcode**. Komputer Windows/Linux dapat mengedit sumber proyek, tetapi tidak dapat menghasilkan build iPhone final tanpa toolchain Apple.

## Fitur utama

- Portal Siswa: `https://sims.emoonzer.com/`
- Presensi
- Tryout
- Scan QR Code ujian
- Reset sesi login/cookie
- WebView terintegrasi dengan sesi SIMS
- Bridge JavaScript kompatibel dengan `Android.startExam`, `startExamWithToken`, dan `setUuid`
- Deteksi otomatis halaman ujian/attempt/tryout
- Verifikasi token keluar ujian
- Verifikasi token keluar sesi QR 10 menit
- Pembatasan domain dan tautan eksternal saat mode ujian
- Copy/paste, cut, context menu, drag-selection dibatasi saat mode ujian
- Deteksi screenshot dan screen recording
- Privacy Shield saat aplikasi masuk app switcher/background
- Deteksi status **Guided Access**
- Indikator online/offline
- Pull-to-refresh saat bukan mode ujian
- Zoom halaman saat mode ujian
- Dialog JavaScript `alert`, `confirm`, dan `prompt` di WKWebView
- Pemulihan otomatis bila proses WKWebView berhenti
- QR Scanner dengan pemeriksaan izin kamera, tombol ke Settings, pemindaian ulang, dan flashlight
- Penanganan error koneksi yang lebih jelas

## Peningkatan versi 1.1.0

1. **Stabilitas sesi WebView**
   - Cookie dipulihkan sebelum halaman pertama dibuka.
   - Cookie sesi SIMS disimpan kembali setelah navigasi selesai.
   - Reset sesi membersihkan cookie/cache WebView.

2. **Mode ujian lebih aman di iPhone**
   - Status Guided Access dibaca langsung dari iOS.
   - Privacy Shield menutup preview isi ujian saat app tidak aktif/background.
   - Perpindahan ke background saat ujian dicatat sebagai peringatan.
   - Screen recording membuat konten tertutup selama capture masih aktif.
   - Navigasi keluar domain ujian diblokir.

3. **QR Scanner diperbaiki**
   - Menangani izin kamera dengan benar.
   - Scanner dapat dipakai kembali setelah QR tidak valid atau konfirmasi dibatalkan.
   - Menampilkan domain QR sebelum pengguna masuk mode ujian.
   - Menolak URL dengan username/password embedded.
   - URL HTTP otomatis dinaikkan ke HTTPS.
   - Tombol flashlight tersedia.

4. **WebView diperbaiki**
   - Tidak lagi mengambil User-Agent melalui private KVC.
   - User-Agent memakai `applicationNameForUserAgent`.
   - JavaScript dialog mendapat UI native iOS.
   - Error loading normal dan error loading saat ujian ditangani.
   - WKWebView yang terminate dapat reload otomatis.
   - Tombol kembali, portal, reload, dan menu diperjelas.

5. **Kepatuhan iOS**
   - Tombol `exit(0)` dihapus. iOS tidak menganjurkan aplikasi menutup dirinya sendiri.
   - AppIcon diperbaiki menjadi **1024 × 1024 RGB tanpa alpha**.
   - Privacy manifest tetap menyertakan alasan penggunaan `UserDefaults`.

## Batasan Apple saat Mode Ujian

| Android | iOS |
|---|---|
| Lock Task / screen pinning aplikasi | Tidak tersedia untuk aplikasi iOS biasa |
| `FLAG_SECURE` mencegah screenshot | Tidak ada padanan penuh |
| Aplikasi dapat mendeteksi screenshot | Ya |
| Aplikasi dapat mendeteksi screen recording | Ya |
| Guided Access | Mekanisme Apple yang disarankan untuk mengunci iPhone pada satu aplikasi |

Moonzer Student **tidak dapat mencegah screenshot aktif secara mutlak** di iOS. Aplikasi mendeteksi screenshot setelah dilakukan, mendeteksi screen recording, dan menutup isi ketika aplikasi berpindah ke background/app switcher.

## Mengaktifkan Guided Access

Sebelum ujian:

1. Buka **Settings / Pengaturan**.
2. Pilih **Accessibility / Aksesibilitas**.
3. Pilih **Guided Access** lalu aktifkan.
4. Atur passcode yang dikuasai pengawas.
5. Buka Moonzer Student dan masuk ke ujian.
6. Klik **3 kali tombol samping** iPhone.
7. Pilih **Start / Mulai**.

Moonzer Student akan menampilkan status **Guided Access** pada menu dan toolbar mode ujian.

## Cara membuka proyek di Mac

1. Salin folder `MoonzerStudent` ke Mac.
2. Buka `MoonzerStudent.xcodeproj` menggunakan **Xcode 15 atau lebih baru**.
3. Pilih target **MoonzerStudent**.
4. Buka **Signing & Capabilities**.
5. Pilih **Team** Apple Developer/Apple ID Anda.
6. Bundle ID default: `com.emoonzer.student`.
7. Pilih iPhone Simulator atau perangkat iPhone.
8. Tekan **Run**.

Target minimum proyek: **iOS 16.0**.

## Izin yang digunakan

`Info.plist` sudah memuat:

- Camera — Scan QR Code ujian.
- Photo Library — jika halaman SIMS meminta unggahan foto/file.
- Location When In Use — jika fitur presensi SIMS menggunakan lokasi.

## Token QR

Endpoint verifikasi:

`https://sims.emoonzer.com/mobile/qr-exit-token/verify`

Pengawas dapat mengambil token melalui halaman admin SIMS:

`https://sims.emoonzer.com/admin/qr-exit-token`

atau perintah Laravel yang sudah digunakan server:

`php artisan qr:exit-token`

## Push Notification

Firebase/APNs **belum dipasang** pada versi ini. Untuk menambahkannya diperlukan:

- Apple Developer Push Notifications capability
- APNs key `.p8`
- `GoogleService-Info.plist`
- Firebase Messaging SDK
- registrasi token APNs/FCM pada backend SIMS

Fitur ini sengaja tidak ditambahkan tanpa konfigurasi Firebase/APNs milik sekolah agar proyek tetap dapat dibuka tanpa dependency eksternal.

## Checklist sebelum distribusi

- [ ] Set Team pada Signing & Capabilities.
- [ ] Pastikan Bundle ID unik dan benar.
- [ ] Jalankan pada iPhone fisik untuk pengujian kamera QR.
- [ ] Uji login SIMS dan pemulihan cookie.
- [ ] Uji Presensi dan izin lokasi bila digunakan.
- [ ] Uji halaman quiz/attempt dan Tryout.
- [ ] Uji token keluar ujian.
- [ ] Uji token keluar QR.
- [ ] Uji Guided Access.
- [ ] Uji screenshot, screen recording, app switcher, dan kembali ke aplikasi.
- [ ] Archive melalui Xcode sebelum TestFlight/App Store.
