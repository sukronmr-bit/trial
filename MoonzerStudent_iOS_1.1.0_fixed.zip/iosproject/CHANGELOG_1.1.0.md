# Moonzer Student iOS — Changelog 1.1.0

## Fixed
- Cookie restore race sebelum initial WebView load.
- QR scanner tidak siap memindai ulang setelah batal/QR invalid.
- Penggunaan private KVC untuk User-Agent WKWebView.
- Penanganan error hanya pada provisional navigation.
- Tidak adanya JavaScript alert/confirm/prompt handler.
- WebView process termination recovery.
- Tombol `exit(0)` yang tidak sesuai pola aplikasi iOS.
- AppIcon yang sebelumnya bukan 1024×1024 dan memiliki alpha channel.

## Added
- Network monitoring online/offline.
- Guided Access status detection.
- Privacy shield saat app inactive/background.
- Deteksi perpindahan aplikasi selama mode ujian.
- Screen recording shield.
- QR camera permission UI + Settings shortcut.
- QR flashlight.
- Domain confirmation sebelum QR session.
- Pull-to-refresh di mode normal.
- Navigation/reload/menu toolbar yang lebih lengkap.
- Token request timeout dan no-cache headers.
- Panduan Mode Ujian iPhone di dalam aplikasi.

## Validation performed in this environment
- Semua file Swift lolos parser Swift (`swiftc -frontend -parse`).
- `Info.plist`, `PrivacyInfo.xcprivacy`, dan `project.pbxproj` lolos `plutil -lint`.
- AppIcon diverifikasi 1024×1024 RGB tanpa alpha.

## Important
Build/Archive iOS final tetap harus diuji di macOS dengan Xcode karena environment perbaikan ini bukan macOS dan tidak memiliki `xcodebuild`/iOS SDK Apple.
